You will need to install python and scipy to run this software.

If you are using Python 3, Python 3's 2to3 tool successfully converts
all of the existing code, and all 100+ unit tests run successfully.

See the Examples directory to get started. All of the examples should
run by typing "python examplename.py" at a command prompt. 

I hope you find this code useful, and to that end I have sprinkled
explanatory comments throughout the code.  If you have any questions
or comments, please e-mail me directly at zunzun@zunzun.com.

     James R. Phillips
     2548 Vera Cruz Drive
     Birmingham, AL 35235 USA

     email: zunzun@zunzun.com
     web: http://zunzun.com
